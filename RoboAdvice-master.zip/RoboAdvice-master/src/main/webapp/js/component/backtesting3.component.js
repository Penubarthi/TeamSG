RoboAdviceApp.component("backTre",{
    bindings: {
    },
    templateUrl: "../../html/backtesting3.html",
    controller: function($scope,CONFIG){
    }
});