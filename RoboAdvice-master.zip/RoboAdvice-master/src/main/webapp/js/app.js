var RoboAdviceApp = angular.module("RoboAdviceApp",["ngRoute","ngResource","ngCookies","ngMessages", "chart.js", "mgo-angular-wizard", "angular-loading-bar"]);
