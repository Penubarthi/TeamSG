package com.roboadvice.service;


import com.roboadvice.model.ApiData;

public interface ApiDataService {

    boolean firstInsert();
    ApiData insert(ApiData ad);




}
