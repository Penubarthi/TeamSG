package com.roboadvice.service;

import com.roboadvice.model.Assets;


public interface AssetsService {

    Assets insert(Assets asset);


}
