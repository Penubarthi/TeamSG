#!/bin/bash

mvn spring-boot:run -Dmaven.test.skil=true
